Authors of media files:
-----------------------

TeddyDesTodes:
Snowflakes licensed under CC-BY-SA 3.0 by from weather branch at https://github.com/TeddyDesTodes/minetest/tree/weather

  * `snow_snowflake1.png` - CC-BY-SA 3.0
  * `snow_snowflake2.png` - CC-BY-SA 3.0

xeranas:

  * `rain_raindrop_1.png` - CC-0
  * `rain_raindrop_2.png` - CC-0
  * `rain_raindrop_3.png` - CC-0

inchadney (http://freesound.org/people/inchadney/):

  * `weather_rain.ogg` - CC-BY-SA 3.0 (cut from http://freesound.org/people/inchadney/sounds/58835/)

