# MOB Horse

### Spawning
There are three different horse textures (white, brown, black) which will spawn on green grassy areas and dry dirt areas in Ethereal mapgen.

---
### Taming
Horses can be tamed with 10x wheat or apples which then allows the player to pick up the horse using a lasso and ride by right-clicking with a saddle.

---
### Horseshoes
Horseshoes can be crafted using steel, bronze, mese and diamond (4x ingots - 2 down either side with 1x block top middle) and placed on a horse by punching with the item.  These can make horses run faster or jump higher depending on tier.

---
### Dead Horse
When riding a horse monsters will generally attack the horse first to get to player riding it, when horse dies the player is dismounted and it will drop any shoes or saddles in use as well as some horse meat.

#### Lucky Blocks: 4
